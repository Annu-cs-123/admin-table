export const data = [
    { userName: 'Annu', email: 'annu@gmail.com', phoneNumber: '123-456-7890', designation: 'Admin', accessStatus: 'Active', userId: '001' },
    { userName: 'Anju', email: 'anju@gmail.com', phoneNumber: '098-765-4321', designation: 'User', accessStatus: 'Inactive', userId: '002' },
    { userName: 'Mandeep', email: 'mandeep@gmail.com', phoneNumber: '12373673355', designation: 'Admin', accessStatus: 'Active', userId: '003' },
    { userName: 'Ankush', email: 'ankush@gmail.com', phoneNumber: '0987674890', designation: 'User', accessStatus: 'Active', userId: '004' },
    { userName: 'Kapil', email: 'kapil@gmail.com', phoneNumber: '12373673355', designation: 'user', accessStatus: 'Active', userId: '005' },
    { userName: 'Deepak', email: 'deepak@gmail.com', phoneNumber: '0987674890', designation: 'User', accessStatus: 'Active', userId: '006' },

]